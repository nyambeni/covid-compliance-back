const express=require('express');
const mysql=require('express');
const app=express();
const PORT=process.env.PORT||4000;
const bodyparse=require('body-parser');
const dbQ=require('./routesAPIs/connection');
const jwt=require('jsonwebtoken');
app.use(bodyparse.urlencoded({extended:true}));
app.use(bodyparse.json());
app.use('/',require('./routesAPIs/AdminAPIs'));
app.use('/',require('./routesAPIs/staffAPIs'));
app.use('/',require('./routesAPIs/studentAPIs'));
app.listen(PORT,()=>{
    console.log('your listen to the app '+PORT);
})