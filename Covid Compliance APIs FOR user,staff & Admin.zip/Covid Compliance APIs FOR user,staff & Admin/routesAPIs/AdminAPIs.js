const express=require('express');
const DBQuer = require('./connection');
const routes=express.Router();
const DBQuery=require('./connection');

//API FOR REVIEWING ALL THE USER DATA
console.log('Yes we can access the API');
routes.get('/user',(req,res)=>{
 DBQuer.query(`SELECT * FROM user`,(error,rows,field)=>{
     try{
                
        res.send(rows);

     }catch{
   console.log('Cant access to the database user');
     }
 })
})
//API FOR REVIEWING BY ID NUMBER ALL THE USER DATA

routes.get('/user/:id_number',(req,res)=>{
 DBQuer.query(`SELECT * FROM user WHERE id_number=?`,[req.params.id_number],(error,rows,field)=>{
     try{
                
        res.send(rows);
        //console.log('Yes we can access User data with an ID in the API'+[req.params.id_number]);

     }catch{
   console.log('Cant access to the database user');
     }
 })
})
//API FOR DELETING USER TABLE WITH AN ID NUBER EITHER STUDENT OR STAFF OR VISTIOR
routes.delete('/user/:id_number',(req,res)=>{
    DBQuer.query(`DELETE FROM user WHERE id_number=?`,[req.params.id_number],(error,rows,field)=>{
        try{
                   
           //console.log('you gave accessed the delete method APIs')
           console.log('You have successfully delete 1 record from the user database ');
   
        }catch{
      console.log('Cant access to the database user');
        }
    })
   })
   //API FOR VEIWING ALL THE DATA IN USER TABLE
   routes.get('/screen',(req,res)=>{
    DBQuer.query(`SELECT * FROM screen `,(error,rows,field)=>{
        try{
                   
           res.send(rows);
           //console.log('Yes we can access User data with an ID in the API'+[req.params.id_number]);
   
        }catch{
      console.log('Cant access to the database user');
        }
    })
   })
 //ACCESSING ONLY DATA WITH THE SCREEN ID  FROM USER TABLE
   routes.get('/screen/:screen_id',(req,res)=>{
    DBQuer.query(`SELECT * FROM screen WHERE screen_id=?`,[req.params.screen_id],(error,rows,field)=>{
        try{
                   
           res.send(rows);
           //console.log('Yes we can access User data with an ID in the API'+[req.params.id_number]);
   
        }catch{
      console.log('Cant access to the database user');
        }
    })
   })
   //API FOR DELETING DATA IN USER TABLE WITH THE UNIQUE SCREEN ID
   routes.delete('/screen/:screen_id',(req,res)=>{
       DBQuer.query(`DELETE FROM screen WHERE id_number=?`,[req.params.screen_id],(error,rows,field)=>{
           try{
                      
              //console.log('you gave accessed the delete method APIs')
              console.log('You have successfully delete 1 record from the user database ');
      
           }catch{
         console.log('Cant access to the database user');
           }
       })
      })
        


module.exports=routes;