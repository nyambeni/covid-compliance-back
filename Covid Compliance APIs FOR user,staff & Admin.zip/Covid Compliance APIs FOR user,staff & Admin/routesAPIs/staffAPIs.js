const express=require('express');
const DBQuer = require('./connection');
const routes=express.Router();
const DBQuery=require('./connection');

//API FOR REVIEWING ALL THE STAFF DATA IN STAFF TABLE

routes.get('/staff',(req,res)=>{
 DBQuer.query(`SELECT * FROM staff`,(error,rows,field)=>{
     try{
        console.log('Yes we can access the API');       
        res.send(rows);

     }catch{
   console.log('Cant access to the database user');
     }
 })
})


// //API FOR REVIEWING BY STAFF NUMBER ALL THE STAFF DATA

routes.get('/staff/:staff_num',(req,res)=>{
 DBQuer.query(`SELECT * FROM staff WHERE staff_num=?`,[req.params.staff_num],(error,rows,field)=>{
     try{
                
        res.send(rows);
        console.log('Yes we can access User data with an ID in the API'+[req.params.staff_num]);

     }catch{
   console.log('Cant access to the database user');
     }
 })
})
//   UPDATE AND EDIT THE STAFF DATABASE  USING STAFF NUMBER
routes.put('/staff/:staff_num',(req,res)=>{
  DBQuer.query(`UPDATE staff SET staff_email=? WHERE staff_num= ?`,[req.body.stud_email,req.params.staff_num],(error,rows,field)=>{
  try{
             
     res.send(rows);
     console.log('managed to update the  User data with an ID in the API '+[req.params.staff_num]);

  }catch{
console.log('Cant update the student table to the database user');
  }
})
})
//API FOR STAFF DELETING DATA 
routes.delete('/staff/:staff_num',(req,res)=>{
    DBQuer.query(`DELETE FROM staff WHERE id_number=?`,[req.params.staff_num],(error,rows,field)=>{
        try{
           console.log('You have successfully delete 1 record from the user database ');
   
        }catch{
      console.log('Cant access to the database user');
        }
    })
   })
   


  //API FOR UPDATING DATA FROM THE USER TABLE 
routes.put('/staff/:staff_num',(req,res)=>{
    DBQuer.query(`UPDATE staff SET staff_role=?,staff_email=? WHERE staff_num= ?`
    ,[req.body.staff_role,req.body.staff_email,req.params.staff_num],(error,rows,field)=>{
    try{
               
       res.send(rows);
       console.log('managed to update the  User data with an ID in the API '+[req.params.staff_num]);

    }catch{
  console.log('Cant update the student table to the database user');
    }
})
})

 module.exports=routes;