const express=require('express');
const mysql=require('mysql');
const { userInfo } = require('os');



const DBQuer=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'',
    database:'covid_compliance'
})

DBQuer.connect((error,rows,field)=>{
    try{
      console.log('Your successfully  connected to the database');
    }catch{
      console.log('Your not corrected ')
    }
})
module.exports=DBQuer;