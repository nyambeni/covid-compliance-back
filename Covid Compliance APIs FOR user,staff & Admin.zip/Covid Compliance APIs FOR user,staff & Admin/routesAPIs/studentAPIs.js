const express=require('express');
const DBQuer = require('./connection');
const routes=express.Router();
const DBQuery=require('./connection');

//API FOR REVIEWING ALL THE USER DATA
routes.get('/student',(req,res)=>{
    DBQuer.query('SELECT * FROM student',(errors,rows,field)=>{
        try{
             res.send(rows);
        }catch{
             console.log('we are unable to access the database from the student');
        }
    })
})

// //API FOR REVIEWING THE DATA BY ID NUMBER ALL THE USER DATA

routes.get('/student/:id_number',(req,res)=>{
 DBQuer.query(`SELECT * FROM student WHERE id_number=?`,[req.params.id_number],(error,rows,field)=>{
     try{
                
        res.send(rows);
        console.log('Yes we can access User data with an ID in the API'+[req.params.id_number]);

     }catch{
   console.log('Cant access to the database user');
     }
 })
})


  //API FOR DELETING THE STUDENT BY ID NUMBER DATA FROM THE USER TABLE
routes.delete('/student/:id_number',(req,res)=>{
    DBQuer.query(`DELETE FROM student WHERE id_number=?`,[req.params.id_number],(error,rows,field)=>{
        try{
                   
           //console.log('you gave accessed the delete method APIs')
           console.log('You have successfully delete 1 record from the user database ');
   
        }catch{
      console.log('Cant access to the database user');
        }
    })
   })
  
   
//   UPDATE AND EDIT THE STUDENT DATABASE  USING STUDENT NUMBER
     routes.put('/student/:stud_num',(req,res)=>{
        DBQuer.query(`UPDATE student SET stud_email=? WHERE stud_num= ?`,[req.body.stud_email,req.params.stud_num],(error,rows,field)=>{
        try{
                   
           res.send(rows);
           console.log('managed to update the  User data with an ID in the API '+[req.params.stud_num]);
   
        }catch{
      console.log('Cant update the student table to the database user');
        }
    })
   })

module.exports=routes;